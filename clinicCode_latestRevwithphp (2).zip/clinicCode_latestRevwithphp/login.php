<?php
$message = '';
include 'src/database.php' ;
$account = SQLiteDatabase('database/clinic.db');

if (isset($_POST['login'])){
  // receive all of the form data
  $ID = $_POST['uId'];
  $Password = $_POST['uPass'];
  try{
    $query = "SELECT * FROM Login WHERE ID = ? AND Password = ? ";
    $stmt = $account -> prepare ($query);
    $stmt -> execute ([$ID,$Password]);
    $data = $stmt ->fetchAll();
    if(!$data){
      $message = '<script>alert("Wrong ID and Password")</script>';
      echo $message ;
    } else{
      header('location:main.html');
    }
  }catch(PDOException $e ){}

}
?>

<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>Login Page</title>
  <link href="https://fonts.googleapis.com/css2?family=Hurricane&family=League+Spartan:wght@600&family=Montserrat&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
  <script src="https://kit.fontawesome.com/cbd813adee.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

  </body>


  <nav id="header-nav" class="navbar navbar-default">
    <font width="600px" style="font-size:80px; font-family: 'Hurricane', cursive;" color="#BB9981"> JIHL </font>
    <font width="600px" style="font-size:60px; font-family: 'Montserrat', sans-serif;" color="#000"> Clinic</font>
    <div class="container">
      <div class="navbar-header">

        <div class="logo hidden-xs">
          <a href="main.html">JIHL Clinic</a>
          <button onclick="myFunction()" class="dropbtn"> Our Services </button>
          <div id="myDropdown" class="dropdown-content">
            <a href="appoinment.html">Appoinment</a>
            <a href="covidTest.html">COVID Test</a>
            <a href="emergency.html">Emergency</a>

            <script>
              function myFunction() {
                document.getElementById("myDropdown").classList.toggle("show");
              }
              window.onclick = function(event) {
                if (!event.target.matches('.dropbtn')) {
                  var dropdowns = document.getElementsByClassName("dropdown-content");
                  var i;
                  for (i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                      openDropdown.classList.remove('show');
                    }
                  }
                }
              }
            </script>

          </div>

          <a href="ourTeam.html">Our Team</a>
          <a href="ourPartners.html">Our Partners</a>
          <a href="aboutUs.html">About Us</a>
          <a href="login.html">Login</a>
          <a href="register.html">Register</a>


        </div>

        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapsable-nav" aria-expanded="false">
          <span class="sr-only">
            Toggle navigation
          </span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>

        <div class="collapse navbar-collapsed" id="collapsable-nav">

          <ul id="nav-list" class="nav
                        navbar-nav navbar-right">
            <hr>
            <li><a href="main.html">JIHL Clinic</a></li>
            <li><a href="appoinment.html">Appoinment</a></li>
            <li><a href="covidTest.html">COVID Test</a></li>
            <li><a href="emergency.html">Emergency</a></li>
            <li><a href="ourTeam.html">Our Team</a></li>
            <li><a href="ourPartners.html">Our Partners</a></li>
            <li><a href="aboutUs.html">About Us</a></li>
            <li><a href="login.html">Login</a></li>
            <li><a href="register.html">Register</a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>

    <div class="login">
      <form method="post">
        <label for="uId" style="font-family: 'League Spartan', sans-serif;">ID:</label>
        <input type="text" id="uId" name="uId"><br><br>
        <label for="uPass">Password:</label>
        <input type="password" id="uPass" name="uPass"><br><br>
          <input type="submit" value="Submit" name='login' id='login' style="	font-family: 'League Spartan', sans-serif">
      </form>
    </div>

    <div class="footer">
      <div>
        <i class="fa-solid fa-phone"></i> Contact Us - Phone: 03-5543 1111 | <i class="fa-solid fa-envelope"></i> Email: JIHLclinic@gmail.com
      </div>
    </div>

  </body>

</html>
